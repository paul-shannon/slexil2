def junk():
	print("entering junk")
	print("leaving junk")

